import json
import logging
import os
import re
from io import BytesIO
from zipfile import ZipFile, BadZipFile
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

ROOT = Path(__file__).resolve().parent.parent
app = FastAPI(title="슈 히스토리")
app.mount("/static", StaticFiles(directory=ROOT / "app/static"), name="static")


def parse_round(row):
    raw = row["all_result"]
    head = re.match(r"^([PBT])([#Y])([#Y])([0-9nN])\*", raw or "")
    position = re.search(r"\*x(\d+)\*y(\d+)\*", raw or "")
    if not head or not position or head[1] != row["result"]:
        raise ValueError(f"Invalid all_result at seq {row['seq']}")
    x, y = int(position[1]), int(position[2])
    if x > 1000 or y > 1000:
        raise ValueError("Coordinate exceeds supported range")
    return {"seq": int(row["seq"]), "result": head[1], "label": head[4],
            "x": x, "y": y, "player_pair": head[2] == "Y",
            "banker_pair": head[3] == "Y", "all_result": raw}


def source_rows(table=None, shoe=None):
    mode = os.getenv("DATA_SOURCE", "sample")
    if mode == "sample":
        rows = json.loads((ROOT / "data/sample.json").read_text())
        return [r for r in rows if (table is None or r['tbl_cd'] == table)
                and (shoe is None or r['file_name'] == shoe)]
    if mode != "oracle":
        raise ValueError("DATA_SOURCE must be sample or oracle")
    import oracledb
    clauses, params = [], {}
    for column, value in (("tbl_cd", table), ("file_name", shoe)):
        if value is not None:
            clauses.append(f"{column} = :{column}")
            params[column] = value
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    # Fixed schema-qualified object; clients and environment cannot change it.
    with oracledb.connect(user=os.environ["ORACLE_USER"], password=os.environ["ORACLE_PASSWORD"],
                          dsn=os.environ["ORACLE_DSN"]) as connection:
        with connection.cursor() as cursor:
            if table is None and shoe is None:
                cursor.execute("SELECT DISTINCT tbl_cd, file_name FROM ERPDEV.C_MAP_BEE_HISTORY ORDER BY tbl_cd, file_name", params)
            else:
                cursor.execute(f"SELECT tbl_cd, file_name, seq, result, all_result FROM ERPDEV.C_MAP_BEE_HISTORY{where} ORDER BY seq", params)
            keys = [c[0].lower() for c in cursor.description]
            return [dict(zip(keys, r)) for r in cursor]


def guarded_read(table=None, shoe=None):
    try:
        return source_rows(table, shoe)
    except Exception:
        logging.exception("History query failed")
        raise HTTPException(503, "데이터 조회 실패: 서버의 데이터 소스 설정을 확인하세요.")


@app.get("/")
def index():
    return FileResponse(ROOT / "app/static/index.html")


@app.get("/api/shoes")
def shoes():
    pairs = sorted({(r["tbl_cd"], r["file_name"]) for r in guarded_read()})
    return {"source": os.getenv("DATA_SOURCE", "sample"),
            "shoes": [{"table": t, "shoe": s} for t, s in pairs]}


@app.get("/api/history")
def history(table: str, shoe: str):
    rows = guarded_read(table, shoe)
    try:
        rounds = [parse_round(r) for r in sorted(rows, key=lambda r: int(r["seq"]))]
        if len({r["seq"] for r in rounds}) != len(rounds) or len({(r["x"], r["y"]) for r in rounds}) != len(rounds):
            raise ValueError("Duplicate sequence or coordinate")
    except (ValueError, TypeError, KeyError):
        raise HTTPException(422, "결과 형식 또는 좌표가 올바르지 않습니다.")
    return {"table": table, "shoe": shoe, "rounds": rounds}


@app.post("/api/upload")
async def upload(request: Request):
    content = bytearray()
    async for chunk in request.stream():
        content.extend(chunk)
        if len(content) > 5 * 1024 * 1024:
            raise HTTPException(413, "엑셀 파일은 5MB 이하로 업로드하세요.")
    import openpyxl
    try:
        with ZipFile(BytesIO(content)) as archive:
            if sum(info.file_size for info in archive.infolist()) > 50 * 1024 * 1024:
                raise HTTPException(413, "압축 해제된 엑셀 데이터가 너무 큽니다.")
        workbook = openpyxl.load_workbook(BytesIO(content), read_only=True, data_only=True)
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(422, "정상적인 .xlsx 파일을 업로드하세요.")
    groups = {}
    count = 0
    try:
        for sheet in workbook:
            values = sheet.iter_rows(values_only=True)
            header = next(values, ())
            keys = [str(v).strip().lower() if v is not None else '' for v in header]
            required = {'tbl_cd', 'file_name', 'seq', 'result', 'all_result'}
            if not required.issubset(keys):
                continue
            if any(keys.count(k) != 1 for k in required):
                raise ValueError("필수 컬럼명이 중복되어 있습니다.")
            for line, values_row in enumerate(values, 2):
                if all(v is None for v in values_row):
                    continue
                count += 1
                if count > 10000:
                    raise ValueError("최대 10,000게임까지 업로드할 수 있습니다.")
                row = dict(zip(keys, values_row))
                if any(row.get(k) is None for k in required):
                    raise ValueError(f"{sheet.title} {line}행: 필수 값이 비어 있습니다.")
                try:
                    parsed = parse_round(row)
                    if parsed['seq'] <= 0 or str(row['seq']) != str(parsed['seq']):
                        raise ValueError()
                except (ValueError, TypeError):
                    raise ValueError(f"{sheet.title} {line}행: seq 또는 all_result 형식이 잘못되었습니다.")
                key = (str(row['tbl_cd']), str(row['file_name']))
                groups.setdefault(key, []).append(parsed)
        if not groups:
            raise ValueError("tbl_cd, file_name, seq, result, all_result 컬럼과 데이터가 필요합니다.")
        for key, rounds in groups.items():
            if len({r['seq'] for r in rounds}) != len(rounds) or len({(r['x'], r['y']) for r in rounds}) != len(rounds):
                raise ValueError(f"{key[0]} / {key[1]}: 중복 게임 순서 또는 좌표가 있습니다.")
            if (max(r['x'] for r in rounds) + 1) * (max(r['y'] for r in rounds) + 1) > 20000:
                raise ValueError("표시할 좌표 영역이 너무 큽니다.")
        return {'shoes': [{'table': t, 'shoe': s, 'rounds': sorted(rounds, key=lambda r: r['seq'])}
                          for (t, s), rounds in sorted(groups.items())], 'count': count}
    except ValueError as exc:
        raise HTTPException(422, str(exc))
    except Exception:
        raise HTTPException(422, "엑셀 데이터를 읽을 수 없습니다.")
    finally:
        workbook.close()
