"""Windows local launcher. Does not persist database credentials."""
import getpass
import os
from pathlib import Path
import subprocess
import sys
import webbrowser
from threading import Timer


def main():
    root = Path(__file__).resolve().parent
    os.chdir(root)
    if sys.version_info < (3, 10):
        raise SystemExit('Python 3.10 이상이 필요합니다. Python 3.12를 권장합니다.')
    python = root / '.venv' / 'Scripts' / 'python.exe'
    if not python.exists():
        subprocess.run([sys.executable, '-m', 'venv', str(root / '.venv')], check=True)
    subprocess.run([str(python), '-m', 'pip', 'install', '-r', 'requirements.txt'], check=True)
    print('\n1. 샘플 / 엑셀 테스트 (DB 연결 없음)\n2. 개발 Oracle DB 연결')
    mode = input('실행 모드 [1]: ').strip() or '1'
    if mode not in {'1', '2'}:
        raise SystemExit('1 또는 2를 선택하세요.')
    environment = os.environ.copy()
    environment['DATA_SOURCE'] = 'oracle' if mode == '2' else 'sample'
    if mode == '2':
        environment['ORACLE_DSN'] = '21.10.10.154:3521/DEVERPU'
        environment['ORACLE_USER'] = 'shoe'
        password = getpass.getpass('shoe 계정 비밀번호 (입력 내용 숨김): ')
        if not password:
            raise SystemExit('비밀번호를 입력해야 합니다.')
        environment['ORACLE_PASSWORD'] = password
    print('\n브라우저 주소: http://127.0.0.1:8000')
    print('서버를 종료하려면 이 창에서 Ctrl+C를 누르세요.')
    timer = Timer(2, lambda: webbrowser.open('http://127.0.0.1:8000'))
    timer.daemon = True
    timer.start()
    try:
        subprocess.run([str(python), '-m', 'uvicorn', 'app.main:app',
                        '--host', '127.0.0.1', '--port', '8000'], env=environment, check=True)
    except KeyboardInterrupt:
        pass
    finally:
        timer.cancel()


if __name__ == '__main__':
    main()
