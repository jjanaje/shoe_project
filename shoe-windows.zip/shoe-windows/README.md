# 슈 히스토리

FastAPI 웹 앱. 기본 실행은 제공된 엑셀에서 추출한 47게임 샘플입니다.

```sh
cd /workspace/shoe_project
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

테이블과 슈를 선택하고 새로고침으로 조회합니다. 플레이어는 파랑, 뱅커는 빨강,
타이는 초록으로 표시합니다. `all_result` 첫 구간의 네 번째 문자를 표시값으로,
`*x...*y...*`를 좌표로 사용합니다. n/N의 의미는 추정하지 않고 원문을 유지합니다.
타이 역시 제공된 좌표에 별도 표시하며 기존 결과 위에 합치지 않습니다.
`tbl_cd`, `file_name`별로 `seq` 오름차순 조회합니다.

화면의 **엑셀 업로드**에서 샘플과 같은 `.xlsx` 파일을 선택하면 DB 접속 없이 결과를
확인할 수 있습니다. 필수 컬럼은 `tbl_cd`, `file_name`, `seq`, `result`, `all_result`입니다.
여러 테이블/슈는 선택 목록으로 분리하며 순서는 `seq` 기준입니다. 최대 5MB/10,000게임을
지원합니다. 잘못된 값·중복 순서·중복 좌표는 오류로 알립니다. 파일은 서버 디스크나 DB에
저장하지 않으며, 파싱 결과는 현재 브라우저 메모리에만 유지합니다. 페이지를 다시 열면
업로드를 다시 해야 합니다. **기본 데이터로 돌아가기**로 서버 데이터 소스를 다시 조회합니다.

Oracle 연결은 서버 프로세스에 `DATA_SOURCE=oracle`, `ORACLE_DSN`, `ORACLE_USER`,
`ORACLE_PASSWORD`를 설정합니다. SQL 대상은 `ERPDEV.C_MAP_BEE_HISTORY`로 고정되어
있으며 환경변수나 API 입력으로 변경할 수 없습니다. 비밀번호를 저장소에 넣지 마세요.
Python-oracledb thin 모드로 연결하며 Oracle Client 설치는 필요하지 않습니다.
DB 조회는 읽기 전용 SELECT와 바인드 변수를 사용합니다. 샘플로 자동 대체하지 않습니다.

실제 DB 연결은 아직 검증하지 않았습니다. `value_yn`, `undo_chk`, `newshoegbn`의 업무 규칙은
확인 전이므로 해당 필터를 적용하지 않습니다. 현재는 선택한 슈 전체 행을 표시합니다.
운영 배포 전에는 접근 인증, DB 권한 제한, 대상 슈 목록 범위를 결정해야 합니다.

DB 권한 제한은 DBA가 별도 신규 조회 계정을 만든 뒤 아래 권한만 부여해야 합니다.
기존 ERPDEV 계정은 테이블 소유 계정일 수 있으므로 앱 전용 계정으로 사용하지 마세요.
아래는 실행하지 않은 DBA용 예시이며 계정 생성과 비밀번호 설정은 DBA가 안전하게 수행합니다.

```sql
GRANT CREATE SESSION TO shoe;
GRANT SELECT ON ERPDEV.C_MAP_BEE_HISTORY TO shoe;
```

전용 계정에는 다른 업무 테이블 권한, 쓰기 권한, 광범위한 역할이나 `SELECT ANY TABLE`을
부여하지 않습니다. PUBLIC/역할을 통한 간접 권한도 DBA가 확인해야 합니다.
`ORACLE_USER=shoe`로 접속 후 허용 테이블 조회 성공 및 다른 업무 테이블
조회 거부를 실제 DB에서 검증해야 DB 수준 제한이 완료됩니다. 앱의 SQL 제한 테스트는
DB 계정 권한 제한을 증명하지 않습니다.

```sh
.venv/bin/python -m unittest discover -s tests -v
```
