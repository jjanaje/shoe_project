# Windows 11 로컬 서버

1. Python 공식 사이트 https://www.python.org/downloads/windows/ 에서 Python 3.12를
   설치합니다. Python launcher(`py`)를 포함해 설치하세요.
2. `shoe-windows.zip`을 압축 해제합니다. ZIP 내부에서 바로 실행하지 마세요.
3. `run-windows.cmd`를 더블클릭합니다. 처음 실행하면 의존성을 설치하므로 인터넷이 필요합니다.
4. `1`은 샘플/엑셀 테스트, `2`는 Oracle 연결입니다. 기본값은 `1`입니다.
5. `2`를 선택하면 shoe 계정 비밀번호를 입력합니다. 화면에 표시하거나 파일에 저장하지 않습니다.
6. 브라우저가 자동으로 열립니다. 서버는 본인 PC의 127.0.0.1:8000에만 열려 있습니다.
   다른 PC나 Netlify에서 이 로컬 서버에 접속하는 방식은 포함하지 않습니다.

Oracle 목적지는 `21.10.10.154:3521/DEVERPU`, 계정은 `shoe`이며 조회는
`ERPDEV.C_MAP_BEE_HISTORY`의 SELECT로 고정됩니다.
사내망/VPN에서 개발 DB에 접근할 수 있어야 합니다. PowerShell에서 접속 여부 확인:

```powershell
Test-NetConnection 21.10.10.154 -Port 3521
```

`TcpTestSucceeded : True`는 TCP 접속만 확인하며 서비스명, 로그인, 테이블 권한까지
검증하지는 않습니다. 앱의 테이블/슈 목록과 결과 조회로 실제 DB 동작을 확인하세요.
DB 계정 생성과 권한 부여는 DBA가 별도 수행해야 합니다.

DB에 기록되는 출발지 IP는 이 PC의 DB 통신 경로에 따라 결정됩니다.
같은 사내망이면 사내 IP, VPN/NAT가 있으면 그 경로에서 변환된 IP가 보일 수 있습니다.
Netlify 엑셀 버전은 로컬 서버 없이 별도로 동작하며 DB에 접속하지 않습니다.

서버 창을 닫거나 Ctrl+C로 종료합니다. 포트 8000이 이미 사용 중이면 기존 프로그램을
확인한 뒤 종료하거나 별도 포트 설정이 필요합니다.
