@echo off
cd /d "%~dp0"
py -3 windows_start.py
if errorlevel 1 (
  echo.
  echo Startup failed. Check Python installation and the error above.
  pause
)
